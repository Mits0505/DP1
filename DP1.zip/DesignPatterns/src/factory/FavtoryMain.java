package factory;

import factory.phone.Android;
import factory.phone.OS;

public class FavtoryMain {

	public static void main(String[] args) {
		OperatingSystemFactory osFactory = new OperatingSystemFactory();
		OS os = osFactory.getInstance("Closed");
		os.spec();
	}

}
